# ❤️ Heart Disease Prediction using Machine Learning

A complete end-to-end Machine Learning project that predicts the likelihood
of heart disease based on patient health information. Built as a BTech
CSE / AI & Data Science college project, using Logistic Regression,
Decision Tree, Random Forest, and (optionally) XGBoost, with a Streamlit
web application for interactive predictions.

---

## 1. Project Overview

Heart disease is one of the leading causes of death worldwide, and early
risk estimation can help people seek medical attention sooner. This project
demonstrates a full applied machine learning workflow — from raw data to a
usable web application — covering data cleaning, exploratory data analysis,
feature engineering, model training and comparison, evaluation, and
deployment through a simple Streamlit interface.

**This is an educational project. It does not provide medical advice or
diagnosis.**

---

## 2. Objectives

- Understand and apply a complete supervised ML pipeline on tabular health data.
- Practice data cleaning, EDA, and feature scaling.
- Train and compare multiple classification algorithms.
- Evaluate models using multiple appropriate metrics, not just accuracy.
- Deploy the best model behind a simple, usable web interface.

---

## 3. Technologies Used

| Category            | Tools/Libraries                     |
|----------------------|--------------------------------------|
| Language             | Python 3.9+                         |
| Data handling        | pandas, numpy                       |
| Visualization        | matplotlib, seaborn                 |
| Machine Learning     | scikit-learn, xgboost (optional)    |
| Model persistence    | joblib                              |
| Web application      | Streamlit                           |
| Notebooks            | Jupyter                             |

---

## 4. Dataset Information

The project uses a dataset with the same column schema as the widely-used
**UCI / Cleveland Heart Disease dataset**:

| Column     | Description                                                   |
|------------|-----------------------------------------------------------------|
| `age`      | Age in years                                                   |
| `sex`      | 1 = male, 0 = female                                            |
| `cp`       | Chest pain type (0-3)                                           |
| `trestbps` | Resting blood pressure (mm Hg)                                  |
| `chol`     | Serum cholesterol (mg/dl)                                       |
| `fbs`      | Fasting blood sugar > 120 mg/dl (1 = true, 0 = false)           |
| `restecg`  | Resting ECG results (0-2)                                       |
| `thalach`  | Maximum heart rate achieved                                     |
| `exang`    | Exercise-induced angina (1 = yes, 0 = no)                       |
| `oldpeak`  | ST depression induced by exercise relative to rest              |
| `slope`    | Slope of the peak exercise ST segment (0-2)                     |
| `ca`       | Number of major vessels colored by fluoroscopy (0-3)            |
| `thal`     | Thalassemia (1 = normal, 2 = fixed defect, 3 = reversible defect)|
| `target`   | 1 = heart disease present, 0 = not present                      |

> **Note on the included `heart_disease.csv`:** This project was built in an
> offline environment without internet access, so the original UCI dataset
> could not be downloaded. The included `heart_disease.csv` is a
> **synthetically generated dataset** (900 rows, see
> `generate_dataset.py`) built from documented medical risk relationships
> (age, cholesterol, chest pain type, exercise-induced angina, etc.), with
> ~2% missing values injected on purpose so the preprocessing code has real
> missing data to handle. All model metrics in this project are computed
> for real on this data — nothing is faked or hard-coded.
>
> **To use the real UCI dataset instead:** simply download it (e.g. from
> the UCI Machine Learning Repository or Kaggle) and replace
> `heart_disease.csv` with a file using the same column names above.
> Every script and notebook will keep working without any code changes.

---

## 5. Project Structure

```
Heart-Disease-Prediction/
│
├── app.py                      # Streamlit web application
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── heart_disease.csv           # Dataset (see note above)
├── generate_dataset.py         # Script used to generate the sample dataset
│
├── models/
│   ├── best_model.pkl          # Trained best-performing model
│   ├── scaler.pkl              # Fitted StandardScaler
│   └── metadata.pkl            # Model name + evaluation metrics
│
├── notebooks/
│   ├── 01_data_exploration.ipynb
│   ├── 02_data_preprocessing.ipynb
│   ├── 03_model_training.ipynb
│   └── 04_model_evaluation.ipynb
│
├── src/
│   ├── data_preprocessing.py   # Reusable cleaning/scaling functions
│   ├── train_model.py          # Trains & compares all models, saves the best
│   ├── generate_eda_plots.py   # Generates EDA charts into outputs/
│   └── predict.py              # Loads model & makes predictions (used by app.py)
│
├── outputs/
│   ├── target_distribution.png
│   ├── age_distribution.png
│   ├── correlation_heatmap.png
│   ├── model_comparison.png
│   ├── model_comparison.csv
│   ├── confusion_matrix.png
│   ├── roc_curve.png
│   └── feature_importance.png
│
└── .gitignore
```

---

## 6. ML Algorithms Used

- **Logistic Regression** — simple, interpretable linear baseline.
- **Decision Tree** — captures non-linear relationships, easy to visualize.
- **Random Forest** — ensemble of trees, usually more robust than a single tree.
- **XGBoost** *(optional)* — gradient boosting, included automatically if the
  `xgboost` package is installed; the project still runs correctly without it.

The best model is automatically selected based on **ROC-AUC** on the test set.

---

## 7. Features

- Clean, well-commented, modular code (`src/` package used by both notebooks and the app).
- Automatic handling of missing values (median for numeric, mode for categorical).
- Stratified train/test split to preserve class balance.
- Feature scaling with `StandardScaler`, saved alongside the model.
- Side-by-side comparison of 3-4 models on 5 metrics.
- Auto-saved visualizations for EDA and evaluation.
- Interactive Streamlit app with clear, non-diagnostic language.
- Clear educational disclaimer shown throughout the app.

---

## 8. Installation Steps

1. **Clone or extract the project** to a folder on your computer.
2. **(Recommended) Create a virtual environment:**

   ```bash
   python -m venv venv
   venv\Scripts\activate        # Windows
   source venv/bin/activate     # macOS/Linux
   ```

3. **Install the dependencies:**

   ```bash
   pip install -r requirements.txt
   ```

   > If `xgboost` fails to install on your machine, you can remove it from
   > `requirements.txt` — the project will simply skip that model.

---

## 9. How to Train the Model

From the project root folder, run:

```bash
python src/train_model.py
```

This will:

1. Load and clean `heart_disease.csv`.
2. Split the data into train/test sets and scale numeric features.
3. Train Logistic Regression, Decision Tree, Random Forest (and XGBoost if available).
4. Compare all models on accuracy, precision, recall, F1-score, and ROC-AUC.
5. Select the best model automatically.
6. Save `best_model.pkl`, `scaler.pkl`, and `metadata.pkl` into `models/`.
7. Save all evaluation charts into `outputs/`.

You can also (optionally) generate the extra EDA charts with:

```bash
python src/generate_eda_plots.py
```

---

## 10. How to Run the Streamlit App

Make sure you have trained the model at least once (Step 9), then run:

```bash
streamlit run app.py
```

This will open the app in your browser (usually at `http://localhost:8501`).

---

## 11. Example Usage

1. Open the app.
2. Fill in the patient details in the **Patient Information** section
   (age, sex, chest pain type, blood pressure, cholesterol, etc.).
3. Click **🔍 Predict**.
4. View the result:
   - **"Low predicted risk based on the trained model"**, or
   - **"Higher predicted risk based on the trained model"**
   - along with the predicted probability.
5. Read the disclaimer — this is an educational prediction, not a diagnosis.

---

## 12. Model Evaluation

Results from the last training run (on the included sample dataset, 20%
held-out test set):

| Model               | Accuracy | Precision | Recall | F1-score | ROC-AUC |
|---------------------|----------|-----------|--------|----------|---------|
| Logistic Regression | 0.672    | 0.653     | 0.719  | 0.684    | 0.746   |
| Random Forest       | 0.667    | 0.663     | 0.663  | 0.663    | 0.726   |
| Decision Tree       | 0.594    | 0.574     | 0.697  | 0.629    | 0.619   |

**Best model selected: Logistic Regression** (highest ROC-AUC).

> These numbers will differ slightly if you re-run training, install
> XGBoost, or (recommended) replace the sample dataset with the real UCI
> dataset, which has cleaner and stronger real-world signal than the
> synthetic sample data included here.

See `outputs/model_comparison.png`, `outputs/confusion_matrix.png`, and
`outputs/roc_curve.png` for visual results.

---

## 13. Screenshots

*(Add your own screenshots here after running the app.)*

- `screenshots/home_page.png` — App home page
- `screenshots/prediction_result.png` — Example prediction result
- `screenshots/sidebar_model_info.png` — Sidebar showing model info

---

## 14. Future Improvements

- Train on the full real UCI/Kaggle dataset (or a larger clinical dataset) for stronger real-world performance.
- Add hyperparameter tuning (GridSearchCV / RandomizedSearchCV / Optuna).
- Add SHAP-based explainability for individual predictions.
- Add user authentication and a prediction history log.
- Deploy the app publicly (Streamlit Community Cloud, Render, etc.).
- Add unit tests for the `src/` modules.

---

## 15. Disclaimer

This project is developed **strictly for educational purposes** as part of
a BTech academic project. The model, predictions, and application:

- Are **NOT** a substitute for professional medical advice, diagnosis, or treatment.
- Should **NOT** be used to make real healthcare decisions.
- Are trained on limited/sample data and have known accuracy limitations.

**Always consult a qualified healthcare professional for any medical concerns.**
