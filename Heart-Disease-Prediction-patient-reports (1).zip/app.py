"""Streamlit interface for the Heart Disease Prediction project."""

import os
import sys
from datetime import date
from html import escape

import pandas as pd
import streamlit as st

try:
    from src.predict import load_artifacts, predict_single
except ImportError:  # pragma: no cover - supports direct execution.
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))
    from predict import load_artifacts, predict_single


st.set_page_config(
    page_title="CardioLens | Heart Risk Estimator",
    page_icon="❤️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .stApp { background: #f6f8fc; }
    [data-testid="stSidebar"] { background: #101828; }
    [data-testid="stSidebar"] * { color: #e6edf7 !important; }
    .hero {
        padding: 2.2rem 2.4rem;
        border-radius: 22px;
        color: white;
        background: linear-gradient(120deg, #152b52 0%, #167d89 100%);
        box-shadow: 0 12px 30px rgba(16, 24, 40, .12);
        margin-bottom: 1.3rem;
    }
    .hero h1 { margin: 0 0 .45rem 0; font-size: 2.35rem; }
    .hero p { margin: 0; color: #d9f5f4; font-size: 1.05rem; }
    .section-card {
        background: white;
        border: 1px solid #e4eaf2;
        border-radius: 18px;
        padding: 1.25rem 1.35rem .7rem;
        box-shadow: 0 6px 18px rgba(16, 24, 40, .05);
    }
    .result-card {
        padding: 1.25rem 1.4rem;
        border-radius: 18px;
        background: white;
        border: 1px solid #dbe4ef;
        box-shadow: 0 8px 24px rgba(16, 24, 40, .08);
    }
    .muted { color: #667085; font-size: .9rem; }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def get_artifacts():
    return load_artifacts()


try:
    model, scaler, metadata = get_artifacts()
    model_loaded = True
except FileNotFoundError as error:
    model_loaded = False
    st.error(str(error))


with st.sidebar:
    st.markdown("## ❤️ CardioLens")
    st.caption("A fast, educational heart-risk estimator")
    st.markdown("---")
    st.markdown("### Model health")
    if model_loaded:
        metrics = metadata.get("metrics", {})
        st.success("Model ready")
        st.metric("Validation accuracy", f"{metrics.get('accuracy', 0):.1%}")
        st.metric("ROC-AUC", f"{metrics.get('roc_auc', 0):.3f}")
        st.caption(f"Algorithm: {metadata.get('model_name', 'Unknown')}")
    else:
        st.warning("Train the model before making predictions.")
    st.markdown("---")
    st.markdown("### Important")
    st.caption(
        "This tool is for education only. It does not diagnose disease or "
        "replace advice from a qualified healthcare professional."
    )


st.markdown(
    """
    <div class="hero">
      <h1>Heart health, made easier to explore.</h1>
      <p>Enter the patient profile below to get an instant, explainable model estimate.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

intro_col, status_col = st.columns([3, 1])
with intro_col:
    st.markdown("### Patient profile")
    st.markdown(
        '<p class="muted">Use the clinical values available to you. '
        "The result is a probability estimate, not a diagnosis.</p>",
        unsafe_allow_html=True,
    )
with status_col:
    if model_loaded:
        st.success("● Live model")

profiles = {
    "Balanced example": {
        "age": 50, "sex": 1, "cp": 1, "trestbps": 130, "chol": 240,
        "fbs": 0, "restecg": 0, "thalach": 150, "exang": 0,
        "oldpeak": 1.0, "slope": 1, "ca": 0, "thal": 1,
    },
    "Lower-risk example": {
        "age": 38, "sex": 0, "cp": 2, "trestbps": 116, "chol": 190,
        "fbs": 0, "restecg": 0, "thalach": 175, "exang": 0,
        "oldpeak": 0.2, "slope": 2, "ca": 0, "thal": 1,
    },
    "Higher-risk example": {
        "age": 67, "sex": 1, "cp": 0, "trestbps": 165, "chol": 310,
        "fbs": 1, "restecg": 1, "thalach": 105, "exang": 1,
        "oldpeak": 3.2, "slope": 0, "ca": 3, "thal": 3,
    },
}
with st.expander("⚡ Quick start with a sample profile"):
    profile_name = st.selectbox(
        "Choose a profile to pre-fill the form",
        list(profiles),
        help="These examples are synthetic and are provided only for demonstration.",
    )
profile = profiles[profile_name]

with st.form("patient_form"):
    st.markdown("#### Report details")
    detail_left, detail_mid, detail_right = st.columns(3)
    with detail_left:
        patient_name = st.text_input("Patient name", placeholder="e.g. Ananya Sharma")
    with detail_mid:
        patient_id = st.text_input("Patient ID", value="CARDIO-001")
    with detail_right:
        report_date = st.date_input("Assessment date", value=date.today())
    clinician_name = st.text_input(
        "Clinician / organisation (optional)",
        placeholder="e.g. Dr. A. Kumar · Wellness Clinic",
    )

    left, right = st.columns(2, gap="large")
    with left:
        st.markdown("#### Basic information")
        age = st.number_input("Age (years)", 1, 120, profile["age"])
        sex = st.selectbox("Sex", [("Male", 1), ("Female", 0)],
                           index=0 if profile["sex"] == 1 else 1,
                           format_func=lambda item: item[0])
        cp = st.selectbox(
            "Chest pain type",
            [
                ("Typical angina", 0),
                ("Atypical angina", 1),
                ("Non-anginal pain", 2),
                ("Asymptomatic", 3),
            ],
            index=profile["cp"], format_func=lambda item: item[0],
        )
        trestbps = st.number_input("Resting blood pressure (mm Hg)", 80, 220, profile["trestbps"])
        chol = st.number_input("Serum cholesterol (mg/dl)", 100, 600, profile["chol"])
        fbs = st.selectbox(
            "Fasting blood sugar > 120 mg/dl?",
            [("No", 0), ("Yes", 1)],
            index=profile["fbs"], format_func=lambda item: item[0],
        )
        restecg = st.selectbox(
            "Resting ECG result",
            [
                ("Normal", 0),
                ("ST-T wave abnormality", 1),
                ("Left ventricular hypertrophy", 2),
            ],
            index=profile["restecg"], format_func=lambda item: item[0],
        )
    with right:
        st.markdown("#### Exercise and circulation")
        thalach = st.number_input("Maximum heart rate achieved", 60, 220, profile["thalach"])
        exang = st.selectbox(
            "Exercise-induced angina?",
            [("No", 0), ("Yes", 1)],
            index=profile["exang"], format_func=lambda item: item[0],
        )
        oldpeak = st.number_input(
            "ST depression (oldpeak)", 0.0, 10.0, profile["oldpeak"], step=0.1
        )
        slope = st.selectbox(
            "Peak exercise ST slope",
            [("Upsloping", 0), ("Flat", 1), ("Downsloping", 2)],
            index=profile["slope"], format_func=lambda item: item[0],
        )
        ca = st.selectbox("Major vessels colored (0–3)", [0, 1, 2, 3], index=profile["ca"])
        thal = st.selectbox(
            "Thalassemia",
            [("Normal", 1), ("Fixed defect", 2), ("Reversible defect", 3)],
            index=profile["thal"] - 1, format_func=lambda item: item[0],
        )
        st.markdown("<br>", unsafe_allow_html=True)
        submitted = st.form_submit_button(
            "🔍  Estimate heart-disease risk",
            type="primary",
            use_container_width=True,
            disabled=not model_loaded,
        )

if submitted and model_loaded:
    patient_data = {
        "age": age,
        "sex": sex[1],
        "cp": cp[1],
        "trestbps": trestbps,
        "chol": chol,
        "fbs": fbs[1],
        "restecg": restecg[1],
        "thalach": thalach,
        "exang": exang[1],
        "oldpeak": oldpeak,
        "slope": slope[1],
        "ca": ca,
        "thal": thal[1],
    }
    try:
        prediction, probability = predict_single(model, scaler, patient_data)
        st.markdown("---")
        st.markdown("### Model result")
        result_col, detail_col = st.columns([1.3, 1], gap="large")
        with result_col:
            if prediction == 1:
                st.error("Higher predicted risk")
                st.markdown(
                    '<div class="result-card"><strong>Action:</strong> '
                    "Please discuss these results with a qualified healthcare "
                    "professional.</div>",
                    unsafe_allow_html=True,
                )
            else:
                st.success("Lower predicted risk")
                st.markdown(
                    '<div class="result-card"><strong>Action:</strong> '
                    "Continue healthy habits and consult a professional for "
                    "any concerns.</div>",
                    unsafe_allow_html=True,
                )
        with detail_col:
            st.metric("Estimated probability", f"{probability:.1%}")
            st.progress(min(max(probability, 0.0), 1.0))
            st.caption("The probability comes from the trained classification model.")
            risk_band = "High" if probability >= 0.7 else "Moderate" if probability >= 0.4 else "Low"
            st.metric("Risk band", risk_band)

        risk_flags = []
        if age >= 55:
            risk_flags.append("Age is 55 or above")
        if trestbps >= 140:
            risk_flags.append("Resting blood pressure is elevated")
        if chol >= 240:
            risk_flags.append("Cholesterol is at or above 240 mg/dl")
        if exang[1] == 1:
            risk_flags.append("Exercise-induced angina is present")
        if oldpeak >= 2:
            risk_flags.append("ST depression is elevated")
        if ca > 0:
            risk_flags.append("Major-vessel count is above zero")
        st.markdown("#### Profile signals")
        if risk_flags:
            st.warning(" • ".join(risk_flags))
        else:
            st.success("No highlighted threshold signals in this profile.")

        report = pd.DataFrame([{
            "patient_name": patient_name.strip() or "Not provided",
            "patient_id": patient_id.strip() or "Not provided",
            "assessment_date": report_date.isoformat(),
            "clinician_or_organisation": clinician_name.strip() or "Not provided",
            **patient_data,
            "prediction": prediction,
            "probability": round(probability, 4),
            "risk_band": risk_band,
        }])
        safe_name = escape(patient_name.strip() or "Patient")
        safe_id = escape(patient_id.strip() or "Not provided")
        safe_clinician = escape(clinician_name.strip() or "Not provided")
        result_label = "Higher predicted risk" if prediction == 1 else "Lower predicted risk"
        signal_rows = "".join(
            f"<li>{escape(signal)}</li>" for signal in risk_flags
        ) or "<li>No highlighted threshold signals in this profile.</li>"
        printable_report = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>CardioLens Report - {safe_name}</title>
<style>
body{{font-family:Arial,sans-serif;color:#172033;max-width:850px;margin:40px auto;padding:0 24px}}
header{{border-bottom:4px solid #167d89;padding-bottom:18px;margin-bottom:24px}}
h1{{margin:0;color:#152b52}} h2{{color:#167d89;margin-top:28px}}
.meta,.result{{background:#f3f7fa;border-radius:10px;padding:16px;margin:12px 0}}
.result{{border-left:6px solid #167d89}} table{{width:100%;border-collapse:collapse}}
td{{padding:9px;border-bottom:1px solid #dbe4ef}} td:first-child{{font-weight:bold;width:42%}}
.notice{{font-size:12px;color:#596579;border-top:1px solid #dbe4ef;margin-top:30px;padding-top:14px}}
@media print{{body{{margin:0}} .no-print{{display:none}}}}
</style></head><body>
<header><h1>CardioLens</h1><div>Heart-risk estimation report</div></header>
<div class="meta"><b>Patient:</b> {safe_name}<br><b>Patient ID:</b> {safe_id}<br>
<b>Assessment date:</b> {escape(report_date.strftime("%d %B %Y"))}<br>
<b>Clinician / organisation:</b> {safe_clinician}</div>
<div class="result"><h2>Model result: {result_label}</h2>
<b>Estimated probability:</b> {probability:.1%}<br><b>Risk band:</b> {risk_band}</div>
<h2>Clinical profile</h2><table>
<tr><td>Age</td><td>{age} years</td></tr><tr><td>Sex</td><td>{"Male" if sex[1] else "Female"}</td></tr>
<tr><td>Chest pain type</td><td>{escape(cp[0])}</td></tr>
<tr><td>Resting blood pressure</td><td>{trestbps} mm Hg</td></tr>
<tr><td>Cholesterol</td><td>{chol} mg/dl</td></tr><tr><td>Maximum heart rate</td><td>{thalach}</td></tr>
<tr><td>Exercise-induced angina</td><td>{"Yes" if exang[1] else "No"}</td></tr>
<tr><td>ST depression</td><td>{oldpeak}</td></tr><tr><td>Major vessels</td><td>{ca}</td></tr>
</table><h2>Profile signals</h2><ul>{signal_rows}</ul>
<p class="notice"><b>Educational disclaimer:</b> This report is generated by a machine-learning
model trained on synthetic sample data. It is not a medical diagnosis, does not replace
clinical judgment, and must not be used for medical decision-making. Print this page
from your browser if a paper copy is needed.</p></body></html>"""
        st.download_button(
            "⬇️ Download prediction report (CSV)",
            report.to_csv(index=False).encode("utf-8"),
            file_name="cardiolens_prediction_report.csv",
            mime="text/csv",
        )
        st.download_button(
            "🖨️ Download printable report (HTML)",
            printable_report.encode("utf-8"),
            file_name="cardiolens_printable_report.html",
            mime="text/html",
            help="Open the downloaded HTML file in a browser and press Ctrl+P to print or save as PDF.",
        )
        st.caption("For a paper/PDF copy: open the HTML report, then press Ctrl+P → Print or Save as PDF.")
        st.info(
            "This result is educational and should never be used for medical "
            "decision-making. Seek urgent care for urgent symptoms."
        )
    except (KeyError, ValueError, TypeError) as error:
        st.error(f"Unable to process these values: {error}")

st.markdown("---")
st.caption(
    "CardioLens • Academic machine-learning project • Trained on synthetic sample data • "
    "Not medical advice"
)
