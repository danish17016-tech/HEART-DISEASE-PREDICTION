"""
generate_eda_plots.py
----------------------
Generates the exploratory data analysis (EDA) visualizations referenced
in the notebooks and README: target distribution, age distribution, and
the correlation heatmap. Run after heart_disease.csv exists.

    python src/generate_eda_plots.py
"""

import os
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

try:
    from .data_preprocessing import load_dataset, clean_data
except ImportError:  # pragma: no cover - allows direct script execution.
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from data_preprocessing import load_dataset, clean_data

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(PROJECT_ROOT, "heart_disease.csv")
OUTPUTS_DIR = os.path.join(PROJECT_ROOT, "outputs")
os.makedirs(OUTPUTS_DIR, exist_ok=True)


def main():
    df = clean_data(load_dataset(DATA_PATH))

    # Target distribution
    plt.figure(figsize=(5, 4))
    sns.countplot(x="target", hue="target", data=df, palette=["#4C72B0", "#DD8452"], legend=False)
    plt.title("Target Distribution (0 = No Disease, 1 = Disease)")
    plt.xlabel("Target")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUTS_DIR, "target_distribution.png"), dpi=150)
    plt.close()

    # Age distribution
    plt.figure(figsize=(6, 4))
    sns.histplot(df["age"], bins=20, kde=True, color="teal")
    plt.title("Age Distribution")
    plt.xlabel("Age")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUTS_DIR, "age_distribution.png"), dpi=150)
    plt.close()

    # Correlation heatmap
    plt.figure(figsize=(10, 8))
    corr = df.corr(numeric_only=True)
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", square=True)
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUTS_DIR, "correlation_heatmap.png"), dpi=150)
    plt.close()

    print("Saved target_distribution.png, age_distribution.png, correlation_heatmap.png to outputs/")


if __name__ == "__main__":
    main()
