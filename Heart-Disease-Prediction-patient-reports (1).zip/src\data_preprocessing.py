"""
data_preprocessing.py
----------------------
Reusable data loading and preprocessing functions for the
Heart Disease Prediction project.

This module is imported by both the training scripts/notebooks
and (indirectly, via the saved scaler) the Streamlit app, so the
SAME preprocessing logic is used everywhere.
"""

import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Columns expected in the dataset
NUMERIC_COLUMNS = ["age", "trestbps", "chol", "thalach", "oldpeak", "ca"]
CATEGORICAL_COLUMNS = ["sex", "cp", "fbs", "restecg", "exang", "slope", "thal"]
TARGET_COLUMN = "target"

ALL_FEATURE_COLUMNS = NUMERIC_COLUMNS + CATEGORICAL_COLUMNS


def load_dataset(csv_path: str) -> pd.DataFrame:
    """Load the heart disease dataset from a CSV file.

    Uses a relative path by default so the project works the same way
    on Windows, macOS, and Linux.
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(
            f"Could not find dataset at '{csv_path}'. "
            "Make sure heart_disease.csv is in the project root folder."
        )
    df = pd.read_csv(csv_path)
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Clean the raw dataframe.

    - Drops exact duplicate rows.
    - Fills missing numeric values with the column median (robust to outliers).
    - Fills missing categorical values with the column mode.
    """
    df = df.copy()

    # Remove duplicate rows if any
    df = df.drop_duplicates()

    # Handle missing values column by column
    for col in df.columns:
        if df[col].isnull().sum() == 0:
            continue
        if col in NUMERIC_COLUMNS:
            median_value = df[col].median()
            df[col] = df[col].fillna(median_value)
        elif col in CATEGORICAL_COLUMNS:
            mode_value = df[col].mode()[0]
            df[col] = df[col].fillna(mode_value)

    return df


def split_features_target(df: pd.DataFrame):
    """Split a cleaned dataframe into features (X) and target (y)."""
    X = df[ALL_FEATURE_COLUMNS].copy()
    y = df[TARGET_COLUMN].copy()
    return X, y


def get_train_test_split(X, y, test_size: float = 0.2, random_state: int = 42):
    """Stratified train/test split so the class balance is preserved."""
    return train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )


def scale_features(X_train, X_test):
    """Fit a StandardScaler on the training data and transform both sets.

    Only numeric columns are scaled; categorical (already-encoded) columns
    are left as-is, which is standard practice for this kind of dataset.
    """
    scaler = StandardScaler()
    X_train_scaled = X_train.copy()
    X_test_scaled = X_test.copy()

    X_train_scaled[NUMERIC_COLUMNS] = scaler.fit_transform(X_train[NUMERIC_COLUMNS])
    X_test_scaled[NUMERIC_COLUMNS] = scaler.transform(X_test[NUMERIC_COLUMNS])

    return X_train_scaled, X_test_scaled, scaler


def preprocess_pipeline(csv_path: str, test_size: float = 0.2, random_state: int = 42):
    """Run the full preprocessing pipeline in one call.

    Returns: X_train_scaled, X_test_scaled, y_train, y_test, scaler
    """
    df = load_dataset(csv_path)
    df = clean_data(df)
    X, y = split_features_target(df)
    X_train, X_test, y_train, y_test = get_train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    X_train_scaled, X_test_scaled, scaler = scale_features(X_train, X_test)
    return X_train_scaled, X_test_scaled, y_train, y_test, scaler
