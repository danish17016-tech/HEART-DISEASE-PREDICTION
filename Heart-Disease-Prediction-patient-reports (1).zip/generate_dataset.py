"""
generate_dataset.py
--------------------
Generates a SYNTHETIC heart disease dataset that follows the same column
schema as the well-known UCI / Cleveland Heart Disease dataset:

    age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang,
    oldpeak, slope, ca, thal, target

Why synthetic data?
This project was built in an offline environment with no internet access,
so the real UCI dataset could not be downloaded. Instead of faking model
results, we generate a reasonably realistic dataset from documented medical
risk relationships (e.g. higher age, higher cholesterol, lower max heart
rate, and exercise-induced angina increase heart disease risk) and then
train genuine models on this data. Every metric reported later in the
project (accuracy, precision, ROC-AUC, etc.) is computed for real on this
data - nothing is hard-coded or faked.

Students using this project on their own machine can simply replace
heart_disease.csv with the original UCI Cleveland dataset (same column
names) and every script will continue to work without any code changes.
"""

import numpy as np
import pandas as pd

RANDOM_SEED = 42
N_SAMPLES = 900

rng = np.random.default_rng(RANDOM_SEED)


def generate_heart_disease_data(n_samples: int = N_SAMPLES) -> pd.DataFrame:
    """Generate a synthetic but medically-plausible heart disease dataset."""

    # ---- Demographics ----
    age = rng.integers(29, 78, n_samples)
    sex = rng.integers(0, 2, n_samples)  # 1 = male, 0 = female

    # ---- Chest pain type (0-3) ----
    cp = rng.integers(0, 4, n_samples)

    # ---- Resting blood pressure (mm Hg) ----
    trestbps = rng.normal(131, 17, n_samples).clip(90, 200)

    # ---- Cholesterol (mg/dl) ----
    chol = rng.normal(246, 51, n_samples).clip(120, 450)

    # ---- Fasting blood sugar > 120 mg/dl (1 = true, 0 = false) ----
    fbs = (rng.random(n_samples) < 0.15).astype(int)

    # ---- Resting ECG results (0-2) ----
    restecg = rng.integers(0, 3, n_samples)

    # ---- Max heart rate achieved ----
    thalach = (210 - 0.7 * age + rng.normal(0, 15, n_samples)).clip(70, 210)

    # ---- Exercise induced angina (1 = yes, 0 = no) ----
    exang_prob = 0.15 + 0.20 * (cp == 0)
    exang = (rng.random(n_samples) < exang_prob).astype(int)

    # ---- ST depression induced by exercise ----
    oldpeak = rng.gamma(1.7, 1.0, n_samples).clip(0, 6.2)

    # ---- Slope of peak exercise ST segment (0-2) ----
    slope = rng.integers(0, 3, n_samples)

    # ---- Number of major vessels colored by fluoroscopy (0-3) ----
    ca = rng.integers(0, 4, n_samples)

    # ---- Thalassemia (1 = normal, 2 = fixed defect, 3 = reversible defect) ----
    thal = rng.integers(1, 4, n_samples)

    # ---- Build a medically-plausible risk score to decide the target ----
    risk_score = (
        0.30 * (age - 50)
        + 2.4 * sex
        + 3.2 * (cp == 0)
        + 0.08 * (trestbps - 130)
        + 0.05 * (chol - 240)
        + 1.9 * fbs
        - 0.09 * (thalach - 150)
        + 3.0 * exang
        + 2.0 * oldpeak
        + 2.2 * (slope == 0)
        + 2.5 * ca
        + 3.2 * (thal == 3)
        + rng.normal(0, 0.3, n_samples)  # moderate noise keeps it realistic but clearly separable
    )

    # Convert risk score into a probability with a logistic function
    probability = 1 / (1 + np.exp(-(risk_score - risk_score.mean())))
    target = (rng.random(n_samples) < probability).astype(int)

    df = pd.DataFrame(
        {
            "age": age.astype(int),
            "sex": sex.astype(int),
            "cp": cp.astype(int),
            "trestbps": trestbps.round(0).astype(int),
            "chol": chol.round(0).astype(int),
            "fbs": fbs.astype(int),
            "restecg": restecg.astype(int),
            "thalach": thalach.round(0).astype(int),
            "exang": exang.astype(int),
            "oldpeak": oldpeak.round(1),
            "slope": slope.astype(int),
            "ca": ca.astype(int),
            "thal": thal.astype(int),
            "target": target.astype(int),
        }
    )

    # ---- Inject a small % of missing values to make preprocessing realistic ----
    for col in ["trestbps", "chol", "thalach"]:
        mask = rng.random(n_samples) < 0.02
        df.loc[mask, col] = np.nan

    return df


if __name__ == "__main__":
    data = generate_heart_disease_data()
    data.to_csv("heart_disease.csv", index=False)
    print(f"Generated {len(data)} rows -> heart_disease.csv")
    print(data["target"].value_counts(normalize=True))
