"""
train_model.py
---------------
Trains multiple classification models on the heart disease dataset,
compares their performance, selects the best model, and saves it
(along with the fitted scaler) so the Streamlit app can load it later.

Run this script from the project root folder:

    python src/train_model.py
"""

import os
import sys
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # so it works without a display (e.g. on servers)
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    roc_curve,
)

try:
    # Package import: python -m src.train_model
    from .data_preprocessing import preprocess_pipeline, ALL_FEATURE_COLUMNS
except ImportError:
    # Direct script execution: python src/train_model.py
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from data_preprocessing import preprocess_pipeline, ALL_FEATURE_COLUMNS

# XGBoost is optional - the project still works fully without it.
try:
    from xgboost import XGBClassifier

    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

# ---------------------------------------------------------------------------
# Paths (all relative, so this works on Windows, macOS and Linux)
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(PROJECT_ROOT, "heart_disease.csv")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")
OUTPUTS_DIR = os.path.join(PROJECT_ROOT, "outputs")

os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)

RANDOM_STATE = 42


def get_models() -> dict:
    """Return a dictionary of models to train and compare."""
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
        "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=RANDOM_STATE),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, max_depth=6, random_state=RANDOM_STATE
        ),
    }
    if XGBOOST_AVAILABLE:
        models["XGBoost"] = XGBClassifier(
            n_estimators=200,
            max_depth=4,
            learning_rate=0.1,
            eval_metric="logloss",
            random_state=RANDOM_STATE,
        )
    else:
        print("[INFO] xgboost is not installed - skipping XGBoost model. "
              "Install it with 'pip install xgboost' to include it.")
    return models


def evaluate_model(model, X_test, y_test) -> dict:
    """Compute standard classification metrics for a fitted model."""
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    return {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred, zero_division=0),
        "recall": recall_score(y_test, y_pred, zero_division=0),
        "f1_score": f1_score(y_test, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_test, y_proba),
        "y_pred": y_pred,
        "y_proba": y_proba,
    }


def plot_model_comparison(results_df: pd.DataFrame, save_path: str):
    plt.figure(figsize=(9, 5))
    metrics_to_plot = ["accuracy", "precision", "recall", "f1_score", "roc_auc"]
    results_df.set_index("model")[metrics_to_plot].plot(kind="bar", figsize=(10, 5))
    plt.title("Model Comparison")
    plt.ylabel("Score")
    plt.ylim(0, 1)
    plt.xticks(rotation=20)
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def plot_confusion_matrix(y_test, y_pred, model_name: str, save_path: str):
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["No Disease", "Disease"],
                yticklabels=["No Disease", "Disease"])
    plt.title(f"Confusion Matrix - {model_name}")
    plt.ylabel("Actual")
    plt.xlabel("Predicted")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def plot_roc_curve(y_test, y_proba, model_name: str, save_path: str):
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    auc_score = roc_auc_score(y_test, y_proba)

    plt.figure(figsize=(5, 5))
    plt.plot(fpr, tpr, label=f"{model_name} (AUC = {auc_score:.2f})")
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random guess")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve - Best Model")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def plot_feature_importance(model, feature_names, model_name: str, save_path: str):
    """Plot feature importance if the model supports it (tree-based models)."""
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    elif hasattr(model, "coef_"):
        importances = np.abs(model.coef_[0])
    else:
        return  # model doesn't expose importances

    importance_df = pd.DataFrame(
        {"feature": feature_names, "importance": importances}
    ).sort_values("importance", ascending=True)

    plt.figure(figsize=(7, 6))
    plt.barh(importance_df["feature"], importance_df["importance"], color="teal")
    plt.title(f"Feature Importance - {model_name}")
    plt.xlabel("Importance")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def main():
    print("Loading and preprocessing data...")
    X_train, X_test, y_train, y_test, scaler = preprocess_pipeline(DATA_PATH)

    models = get_models()
    results = []
    fitted_models = {}

    print("Training models...")
    for name, model in models.items():
        model.fit(X_train, y_train)
        metrics = evaluate_model(model, X_test, y_test)
        fitted_models[name] = (model, metrics)
        results.append(
            {
                "model": name,
                "accuracy": metrics["accuracy"],
                "precision": metrics["precision"],
                "recall": metrics["recall"],
                "f1_score": metrics["f1_score"],
                "roc_auc": metrics["roc_auc"],
            }
        )
        print(f"  {name}: accuracy={metrics['accuracy']:.3f}, "
              f"f1={metrics['f1_score']:.3f}, roc_auc={metrics['roc_auc']:.3f}")

    results_df = pd.DataFrame(results).sort_values("roc_auc", ascending=False)
    print("\nModel comparison (sorted by ROC-AUC):")
    print(results_df.to_string(index=False))

    # ---- Select the best model based on ROC-AUC ----
    best_model_name = results_df.iloc[0]["model"]
    best_model, best_metrics = fitted_models[best_model_name]
    print(f"\nBest model selected: {best_model_name}")

    # ---- Save visualizations ----
    plot_model_comparison(results_df, os.path.join(OUTPUTS_DIR, "model_comparison.png"))
    plot_confusion_matrix(
        y_test, best_metrics["y_pred"], best_model_name,
        os.path.join(OUTPUTS_DIR, "confusion_matrix.png"),
    )
    plot_roc_curve(
        y_test, best_metrics["y_proba"], best_model_name,
        os.path.join(OUTPUTS_DIR, "roc_curve.png"),
    )
    plot_feature_importance(
        best_model, ALL_FEATURE_COLUMNS, best_model_name,
        os.path.join(OUTPUTS_DIR, "feature_importance.png"),
    )

    # ---- Save the model, scaler, and metadata ----
    joblib.dump(best_model, os.path.join(MODELS_DIR, "best_model.pkl"))
    joblib.dump(scaler, os.path.join(MODELS_DIR, "scaler.pkl"))

    metadata = {
        "model_name": best_model_name,
        "feature_columns": ALL_FEATURE_COLUMNS,
        "metrics": {
            "accuracy": best_metrics["accuracy"],
            "precision": best_metrics["precision"],
            "recall": best_metrics["recall"],
            "f1_score": best_metrics["f1_score"],
            "roc_auc": best_metrics["roc_auc"],
        },
    }
    joblib.dump(metadata, os.path.join(MODELS_DIR, "metadata.pkl"))

    results_df.to_csv(os.path.join(OUTPUTS_DIR, "model_comparison.csv"), index=False)

    print("\nSaved:")
    print(f"  - {os.path.join('models', 'best_model.pkl')}")
    print(f"  - {os.path.join('models', 'scaler.pkl')}")
    print(f"  - {os.path.join('models', 'metadata.pkl')}")
    print(f"  - Visualizations in '{os.path.relpath(OUTPUTS_DIR, PROJECT_ROOT)}/'")


if __name__ == "__main__":
    main()
