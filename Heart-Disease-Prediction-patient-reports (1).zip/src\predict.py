"""
predict.py
----------
Helper functions to load the saved model/scaler and make predictions
on new patient data. Used by the Streamlit app (app.py).
"""

import os
import joblib
import pandas as pd

try:
    from .data_preprocessing import NUMERIC_COLUMNS, ALL_FEATURE_COLUMNS
except ImportError:  # pragma: no cover - allows direct script execution.
    from data_preprocessing import NUMERIC_COLUMNS, ALL_FEATURE_COLUMNS

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")


def load_artifacts():
    """Load the trained model, scaler, and metadata from the models/ folder."""
    model_path = os.path.join(MODELS_DIR, "best_model.pkl")
    scaler_path = os.path.join(MODELS_DIR, "scaler.pkl")
    metadata_path = os.path.join(MODELS_DIR, "metadata.pkl")

    for path in [model_path, scaler_path]:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"Could not find '{path}'. "
                "Please run 'python src/train_model.py' first to train and save the model."
            )

    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    metadata = joblib.load(metadata_path) if os.path.exists(metadata_path) else {}

    return model, scaler, metadata


def predict_single(model, scaler, patient_dict: dict):
    """Predict heart disease risk for a single patient.

    Parameters
    ----------
    patient_dict : dict
        Dictionary with keys matching ALL_FEATURE_COLUMNS.

    Returns
    -------
    prediction : int (0 = no disease, 1 = disease)
    probability : float (probability of the "disease" class)
    """
    input_df = pd.DataFrame([patient_dict])[ALL_FEATURE_COLUMNS]

    # Apply the SAME scaling that was used during training
    input_scaled = input_df.copy()
    input_scaled[NUMERIC_COLUMNS] = scaler.transform(input_df[NUMERIC_COLUMNS])

    prediction = int(model.predict(input_scaled)[0])
    probability = float(model.predict_proba(input_scaled)[0][1])

    return prediction, probability
